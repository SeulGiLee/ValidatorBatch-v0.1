/**
 * 
 */
package com.git.gdsbuilder.type.validate.option;

import java.util.ArrayList;

/**
 * @className QAOptionList.java
 * @description
 * @author DY.Oh
 * @date 2018. 3. 14. 오후 1:45:19
 */
@SuppressWarnings("serial")
public class QAOptionList extends ArrayList<QAOption> {

}
