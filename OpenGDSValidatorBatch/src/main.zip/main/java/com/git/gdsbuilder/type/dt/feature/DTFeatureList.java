package com.git.gdsbuilder.type.dt.feature;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class DTFeatureList extends ArrayList<DTFeature> {

}
